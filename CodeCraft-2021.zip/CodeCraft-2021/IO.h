#ifndef _IO_
#define _IO_
class InputDecoder
{
private:
    /* data */
public:
    InputDecoder(/* args */);
    ~InputDecoder();
};
class OutputEncoder
{
private:
    /* data */
public:
    OutputEncoder(/* args */);
    ~OutputEncoder();
};


#endif