#ifndef _REQUEST_
#define _REQUEST_
class Request
{
private:
    /* data */
public:

};
class AddRequest : public Request
{
    public:
    AddRequest();
};

class DelRequest : public Request
{
};

#endif