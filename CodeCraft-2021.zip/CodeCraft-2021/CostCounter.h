#ifndef _COST_COUNTER_
#define _COST_COUNTER_

class CostCounter
{
private:
    /* data */
public:
    CostCounter(/* args */);
    ~CostCounter();
};


#endif